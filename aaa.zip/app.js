const express = require('express');
const multer = require('multer');
const { removeBackground } = require('@imgly/background-removal-node');
const path = require('path');
const fs = require('fs');

const app = express();
const port = process.env.PORT || 3000;

// Configure multer for file upload
const upload = multer({ dest: 'uploads/' });

// Serve static files from 'public' directory
app.use(express.static('public'));

// Serve the main HTML page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Handle file upload and background removal
app.post('/remove-background', upload.single('image'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'No file uploaded' });
        }

        // Remove background
        const blob = await removeBackground(req.file.path);
        const buffer = Buffer.from(await blob.arrayBuffer());
        
        // Generate output filename
        const outputFilename = `output_${Date.now()}.png`;
        const outputPath = path.join(__dirname, 'public', 'outputs', outputFilename);
        
        // Ensure outputs directory exists
        if (!fs.existsSync(path.join(__dirname, 'public', 'outputs'))) {
            fs.mkdirSync(path.join(__dirname, 'public', 'outputs'), { recursive: true });
        }

        // Save the processed image
        fs.writeFileSync(outputPath, buffer);

        // Get file size
        const stats = fs.statSync(outputPath);
        const fileSize = stats.size;

        // Clean up uploaded file
        fs.unlinkSync(req.file.path);

        // Send response with the path to the processed image
        res.json({ 
            success: true, 
            outputPath: `/outputs/${outputFilename}`,
            fileSize: fileSize
        });
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Error processing image' });
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});